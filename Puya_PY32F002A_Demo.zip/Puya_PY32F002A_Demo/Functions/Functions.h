#ifndef __FUNCTIONS_H
#define __FUNCTIONS_H

extern void USART_Putch(unsigned char c);
extern void USART_String(unsigned char *s, unsigned int Length);
extern void UsartReceiveInterrupt(unsigned char d);

#endif
