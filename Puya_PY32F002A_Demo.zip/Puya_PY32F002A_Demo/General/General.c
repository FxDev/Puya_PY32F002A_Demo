#include "General.h"

unsigned long ADC_Data_0;
unsigned long USART_Data;
