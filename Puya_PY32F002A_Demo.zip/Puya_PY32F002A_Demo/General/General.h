#ifndef __GENERAL_H
#define __GENERAL_H

#include "main.h"
#include "py32f0xx_it.h"
#include "pv_startup.h"
#include "pv_delay.h"
#include "cocoos.h"
#include "Init.h"
#include "Functions.h"

extern unsigned long ADC_Data_0;
extern unsigned long USART_Data;

#endif
