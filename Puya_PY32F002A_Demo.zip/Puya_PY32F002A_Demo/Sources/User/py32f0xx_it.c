#include "General.h"

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
  while (1)
  {
  }
}

void SVC_Handler(void)
{
}


void PendSV_Handler(void)
{
}

void SysTick_Handler(void)		// 1ms kesme
{
	//LED_TOGGLE;
	os_tick();
}

void TIM1_BRK_UP_TRG_COM_IRQHandler(void)
{
  if((LL_TIM_ReadReg(TIM1,SR) & LL_TIM_SR_UIF) == 1 && LL_TIM_IsEnabledIT_UPDATE(TIM1))
  {
    LL_TIM_ClearFlag_UPDATE(TIM1);
		
		//LED_ON;
  }
}

void USART1_IRQHandler(void)
{
  // Parity Error
  if (LL_USART_IsActiveFlag_PE(USART1))
  {
    LL_USART_ClearFlag_PE(USART1);
  }
  // Framing Error
  if (LL_USART_IsActiveFlag_FE(USART1))
  {
    LL_USART_ClearFlag_FE(USART1);
  }
  // OverRun Error
  if (LL_USART_IsActiveFlag_ORE(USART1))
  {
    LL_USART_ClearFlag_ORE(USART1);
  }
  // Noise error
  if (LL_USART_IsActiveFlag_NE(USART1))
  {
    LL_USART_ClearFlag_NE(USART1);
  }
  // RX Not Empty, RX Not Empty Interrupt is enabled
  if (LL_USART_IsActiveFlag_RXNE(USART1) && LL_USART_IsEnabledIT_RXNE(USART1))
  {
    // Read one byte
		UsartReceiveInterrupt(LL_USART_ReceiveData8(USART1));
		//LED_TOGGLE;
		
    // Read USART_DR will clear RXNE flag, so LL_USART_ClearFlag_RXNE() is not necessary
  }
}

void ADC_COMP_IRQHandler(void)
{
  if(LL_ADC_IsActiveFlag_EOC(ADC1) != 0)
  {
    LL_ADC_ClearFlag_EOC		(ADC1);
		
		ADC_Data_0 							= LL_ADC_REG_ReadConversionData12(ADC1);
		
		//LED_TOGGLE;
  }
}
