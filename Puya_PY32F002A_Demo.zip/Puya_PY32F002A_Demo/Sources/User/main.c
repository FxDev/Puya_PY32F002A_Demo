#include "General.h"

void Task_1(void);
void Task_2(void);
void Task_3(void);

unsigned short Task_1_ID;
unsigned short Task_2_ID;
unsigned short Task_3_ID;

unsigned char Task_1_Data[1];
unsigned char Task_2_Data[1];
unsigned char Task_3_Data[1];

unsigned char Reklam[20]="firatdeveci.com\r\n";

int main(void)
{
  PV_STARTUP_Init();

	General_GPIO_Init();
	General_Timer1_Init();
	//General_ADC1_Init();
	General_USART_Init();
	
	os_init();                                                                  // RTOS ilk ayarlari yapiliyor
	Task_1_ID   = task_create(Task_1, &Task_1_Data, 1, 0, 0, 0);                // 1. task olusturuluyor, oncelik 1
	Task_2_ID   = task_create(Task_2, &Task_2_Data, 2, 0, 0, 0);                // 2. task olusturuluyor, oncelik 2
	Task_3_ID   = task_create(Task_3, &Task_3_Data, 3, 0, 0, 0);                // 3. task olusturuluyor, oncelik 3

	os_start();                                                                 // RTOS calistiriliyor

	for(;;);
}

void Task_1(void)                                                       			// Gorev 1: 1ms'de bir isletiliyor
{
	task_open();
	for(;;)
	{
		task_wait(1);
	}
	task_close();
}

void Task_2(void)																															// Gorev 2: 1ms'de bir isletiliyor
{
	task_open();
	for(;;)
	{
		task_wait(10);
	}
	task_close();
}

void Task_3(void)																															// Gorev 3: 1ms'de bir isletiliyor
{
	task_open();
	for(;;)
	{
		task_wait(100);
		
		if(USART_Data == 'A') LED_ON;
		else if(USART_Data == 'B') LED_OFF;
		else if(USART_Data == 'C') LED_TOGGLE;
		
		USART_String(Reklam,17);
	}
	task_close();
}

void MainLoop(void)
{
	
}

void APP_ErrorHandler(void)
{
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  while (1)
  {
  }
}
#endif

