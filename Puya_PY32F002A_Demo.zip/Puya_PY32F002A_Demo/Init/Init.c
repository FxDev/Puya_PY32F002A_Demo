#include "General.h"

void General_GPIO_Init(void)
{
  LL_IOP_GRP1_EnableClock								(LL_IOP_GRP1_PERIPH_GPIOA);

  LL_GPIO_InitTypeDef 									LL_GPIO_InitStruture;
	
  LL_GPIO_InitStruture.Mode 						= LL_GPIO_MODE_OUTPUT;
  LL_GPIO_InitStruture.OutputType 			= LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_InitStruture.Pin 							= LL_GPIO_PIN_1;
  LL_GPIO_InitStruture.Pull 						= LL_GPIO_PULL_NO;
  LL_GPIO_InitStruture.Speed 						= LL_GPIO_SPEED_FREQ_VERY_HIGH;
	
  LL_GPIO_Init													(GPIOA, &LL_GPIO_InitStruture);
}

void General_Timer1_Init(void)
{
	LL_TIM_InitTypeDef 										TIM_InitStructure;
	
	LL_APB1_GRP2_EnableClock							(LL_APB1_GRP2_PERIPH_TIM1);
	
	TIM_InitStructure.ClockDivision				= LL_TIM_CLOCKDIVISION_DIV1;
	TIM_InitStructure.CounterMode     		= LL_TIM_COUNTERMODE_CENTER_UP;
	TIM_InitStructure.Prescaler						= 0;
	TIM_InitStructure.Autoreload					= SystemCoreClock/PWM_FREQUENCY;
	TIM_InitStructure.RepetitionCounter		= 0;
	
	LL_TIM_SetTriggerOutput								(TIM1,LL_TIM_TRGO_UPDATE);
	
	LL_TIM_Init														(TIM1,&TIM_InitStructure);
  LL_TIM_ClearFlag_UPDATE								(TIM1);
  LL_TIM_EnableARRPreload								(TIM1);
	
	//LL_TIM_EnableIT_UPDATE								(TIM1);
  //NVIC_EnableIRQ												(TIM1_BRK_UP_TRG_COM_IRQn);
  //NVIC_SetPriority											(TIM1_BRK_UP_TRG_COM_IRQn,1);
	
	LL_TIM_EnableCounter									(TIM1);
}

void General_USART_Init(void)
{
	LL_APB1_GRP2_EnableClock							(LL_APB1_GRP2_PERIPH_USART1);
	LL_IOP_GRP1_EnableClock								(LL_IOP_GRP1_PERIPH_GPIOA);
	
	LL_GPIO_InitTypeDef 									GPIO_InitStruct;
	LL_USART_InitTypeDef 									USART_InitStruct;
	
	GPIO_InitStruct.Pin 									= LL_GPIO_PIN_2;
	GPIO_InitStruct.Mode 									= LL_GPIO_MODE_ALTERNATE;
	GPIO_InitStruct.Speed 								= LL_GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.OutputType						= LL_GPIO_OUTPUT_PUSHPULL;
	GPIO_InitStruct.Pull 									= LL_GPIO_PULL_UP;
	GPIO_InitStruct.Alternate 						= LL_GPIO_AF1_USART1;
	
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.Pin 									= LL_GPIO_PIN_10;
	GPIO_InitStruct.Alternate 						= LL_GPIO_AF1_USART1;
	
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	/* USART1 Init */
	NVIC_SetPriority											(USART1_IRQn,0);
	NVIC_EnableIRQ												(USART1_IRQn);
	LL_USART_EnableIT_RXNE								(USART1);
	
	USART_InitStruct.BaudRate 						= BAUDRATE;
	USART_InitStruct.DataWidth 						= LL_USART_DATAWIDTH_8B;
	USART_InitStruct.StopBits 						= LL_USART_STOPBITS_1;
	USART_InitStruct.Parity 							= LL_USART_PARITY_NONE;
  USART_InitStruct.TransferDirection 		= LL_USART_DIRECTION_TX_RX;
  USART_InitStruct.HardwareFlowControl 	= LL_USART_HWCONTROL_NONE;
  USART_InitStruct.OverSampling 				= LL_USART_OVERSAMPLING_16;
	
	LL_USART_Init													(USART1, &USART_InitStruct);
  LL_USART_ConfigAsyncMode							(USART1);
  LL_USART_Enable												(USART1);
}

void General_ADC1_Init(void)
{
	LL_ADC_Reset													(ADC1);
	
  LL_IOP_GRP1_EnableClock								(LL_IOP_GRP1_PERIPH_GPIOA);
	LL_APB1_GRP2_EnableClock							(LL_APB1_GRP2_PERIPH_ADC1);
	
	ADC1_Calibrate();
	
  LL_GPIO_SetPinMode										(GPIOA, LL_GPIO_PIN_4, LL_GPIO_MODE_ANALOG);
  LL_ADC_SetCommonPathInternalCh				(__LL_ADC_COMMON_INSTANCE(ADC1), LL_ADC_PATH_INTERNAL_NONE);
	
  LL_ADC_SetClock												(ADC1, LL_ADC_CLOCK_SYNC_PCLK_DIV2);
  LL_ADC_SetResolution									(ADC1, LL_ADC_RESOLUTION_12B);
  LL_ADC_SetResolution									(ADC1, LL_ADC_DATA_ALIGN_RIGHT);
  LL_ADC_SetLowPowerMode								(ADC1, LL_ADC_LP_MODE_NONE);
  LL_ADC_SetSamplingTimeCommonChannels	(ADC1, LL_ADC_SAMPLINGTIME_41CYCLES_5);
	
  LL_ADC_REG_SetTriggerSource						(ADC1, LL_ADC_REG_TRIG_EXT_TIM1_TRGO);
  LL_ADC_REG_SetTriggerEdge							(ADC1, LL_ADC_REG_TRIG_EXT_RISING);
  LL_ADC_REG_SetContinuousMode					(ADC1, LL_ADC_REG_CONV_SINGLE);
  LL_ADC_REG_SetOverrun									(ADC1, LL_ADC_REG_OVR_DATA_OVERWRITTEN);
  LL_ADC_REG_SetSequencerDiscont				(ADC1, LL_ADC_REG_SEQ_DISCONT_DISABLE);
	
  LL_ADC_REG_SetSequencerChannels				(ADC1, LL_ADC_CHANNEL_4);

  LL_ADC_Enable													(ADC1);
  LL_mDelay(1);
	
  LL_ADC_EnableIT_EOC										(ADC1);
  NVIC_SetPriority											(ADC_COMP_IRQn, 0);
  NVIC_EnableIRQ												(ADC_COMP_IRQn);
	
	LL_ADC_REG_StartConversion						(ADC1);
}

#define ADC_CALIBRATION_TIMEOUT_MS    	((uint32_t) 1)
#define USE_ADC_TIMEOUT									( 1 )

void ADC1_Calibrate(void)
{
  __IO uint32_t wait_loop_index = 0;
	#if (USE_ADC_TIMEOUT == 1)
  uint32_t Timeout = 0;
	#endif

  if (LL_ADC_IsEnabled(ADC1) == 0)
  {
    LL_ADC_StartCalibration(ADC1);

		#if (USE_ADC_TIMEOUT == 1)
		Timeout = ADC_CALIBRATION_TIMEOUT_MS;
		#endif

		while (LL_ADC_IsCalibrationOnGoing(ADC1) != 0)
    {
		#if (USE_ADC_TIMEOUT == 1)
      if (LL_SYSTICK_IsActiveCounterFlag())
      {
        if(Timeout-- == 0)
        {

        }
      }
		#endif
    }
		LL_mDelay(1);
  }
}
