#ifndef __INIT_H
#define __INIT_H

#define BAUDRATE						460800UL
#define PWM_FREQUENCY				25000UL

#define LED_ON							LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_1)
#define LED_OFF							LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_1)
#define LED_TOGGLE					LL_GPIO_TogglePin(GPIOA, LL_GPIO_PIN_1)

#define ADC_SAMPLE_NUMBER		3

extern volatile unsigned short ADC_Data[ADC_SAMPLE_NUMBER];

extern void General_GPIO_Init(void);
extern void General_Timer1_Init(void);
extern void General_USART_Init(void);
extern void General_ADC1_Init(void);
extern void ADC1_Calibrate(void);

#endif
