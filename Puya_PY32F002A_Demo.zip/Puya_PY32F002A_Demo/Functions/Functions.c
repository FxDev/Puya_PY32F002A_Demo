#include "General.h"

void USART_Putch(unsigned char c)
{
	LL_USART_TransmitData8(USART1, c);
	while (!LL_USART_IsActiveFlag_TC(USART1));
	LL_USART_ClearFlag_TC(USART1);
}

void USART_String(unsigned char *s, unsigned int Length)
{
	while(Length)
	{
		USART_Putch(*s++);
		Length--;
	}
}

void UsartReceiveInterrupt(unsigned char d)
{
	USART_Data = d;
}
